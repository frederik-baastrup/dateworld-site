<footer class="foot">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-brand"><svg role="img" aria-label="Dateworld" viewBox="0 0 233 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g fill="#fff"><path d="M102.945 5.2H110.395L115.545 23.3L120.395 5.2H126.745L131.445 23.35L136.695 5.2H143.895L135.445 30.9H127.945L123.445 15.4L118.845 30.9H111.345L102.945 5.2Z"/><path d="M158.18 31.2C155.48 31.2 153.096 30.6667 151.03 29.6C148.996 28.5 147.413 26.95 146.28 24.95C145.18 22.95 144.63 20.65 144.63 18.05C144.63 15.45 145.18 13.15 146.28 11.15C147.413 9.15 148.996 7.61667 151.03 6.55C153.096 5.45 155.48 4.9 158.18 4.9C160.88 4.9 163.246 5.45 165.28 6.55C167.346 7.61667 168.93 9.15 170.03 11.15C171.163 13.15 171.73 15.45 171.73 18.05C171.73 20.6833 171.163 23 170.03 25C168.93 26.9667 167.346 28.5 165.28 29.6C163.246 30.6667 160.88 31.2 158.18 31.2ZM158.18 25.45C160.146 25.45 161.696 24.7667 162.83 23.4C163.996 22.0333 164.58 20.25 164.58 18.05C164.58 15.85 163.996 14.0667 162.83 12.7C161.696 11.3333 160.146 10.65 158.18 10.65C156.246 10.65 154.696 11.3333 153.53 12.7C152.396 14.0667 151.83 15.85 151.83 18.05C151.83 20.25 152.396 22.0333 153.53 23.4C154.696 24.7667 156.246 25.45 158.18 25.45Z"/><path d="M191.26 5.2V11.6H188.46C186.46 11.6 184.993 12.2 184.06 13.4C183.127 14.6 182.66 16.2333 182.66 18.3V30.9H175.61V5.2H182.01L182.66 9.05C183.427 7.78334 184.377 6.83333 185.51 6.2C186.643 5.53333 188.16 5.2 190.06 5.2H191.26Z"/><path d="M194.409 0H201.459V30.9H194.409V0Z"/><path d="M232.072 0V30.9H225.922L225.222 27.35C223.255 29.9167 220.589 31.2 217.222 31.2C214.955 31.2 212.922 30.6667 211.122 29.6C209.322 28.5 207.905 26.95 206.872 24.95C205.872 22.95 205.372 20.6333 205.372 18C205.372 15.4 205.872 13.1167 206.872 11.15C207.905 9.15 209.322 7.61667 211.122 6.55C212.955 5.45 215.005 4.9 217.272 4.9C220.605 4.9 223.189 6.06667 225.022 8.4V0H232.072ZM218.872 25.45C220.772 25.45 222.289 24.7833 223.422 23.45C224.555 22.0833 225.122 20.3 225.122 18.1C225.122 15.8667 224.555 14.0667 223.422 12.7C222.289 11.3333 220.772 10.65 218.872 10.65C216.972 10.65 215.439 11.3333 214.272 12.7C213.139 14.0667 212.572 15.85 212.572 18.05C212.572 20.25 213.139 22.0333 214.272 23.4C215.439 24.7667 216.972 25.45 218.872 25.45Z"/></g>
        <g fill="#D81F45"><path d="M26.7 0V30.9H20.55L19.85 27.35C17.8833 29.9167 15.2167 31.2 11.85 31.2C9.58333 31.2 7.55 30.6667 5.75 29.6C3.95 28.5 2.53333 26.95 1.5 24.95C0.5 22.95 0 20.6333 0 18C0 15.4 0.5 13.1167 1.5 11.15C2.53333 9.15 3.95 7.61667 5.75 6.55C7.58333 5.45 9.63333 4.9 11.9 4.9C15.2333 4.9 17.8167 6.06667 19.65 8.4V0H26.7ZM13.5 25.45C15.4 25.45 16.9167 24.7833 18.05 23.45C19.1833 22.0833 19.75 20.3 19.75 18.1C19.75 15.8667 19.1833 14.0667 18.05 12.7C16.9167 11.3333 15.4 10.65 13.5 10.65C11.6 10.65 10.0667 11.3333 8.9 12.7C7.76667 14.0667 7.2 15.85 7.2 18.05C7.2 20.25 7.76667 22.0333 8.9 23.4C10.0667 24.7667 11.6 25.45 13.5 25.45Z"/><path d="M56.9152 24.95V30.9H53.3152C50.0819 30.9 48.4986 29.5 48.5652 26.7C47.6319 28.1667 46.4819 29.2833 45.1152 30.05C43.7486 30.8167 42.0986 31.2 40.1652 31.2C37.2986 31.2 34.9819 30.55 33.2152 29.25C31.4819 27.9167 30.6152 26.05 30.6152 23.65C30.6152 20.9167 31.6152 18.8167 33.6152 17.35C35.6486 15.85 38.5819 15.1 42.4152 15.1H47.5152V13.85C47.5152 12.6833 47.0819 11.7667 46.2152 11.1C45.3486 10.4 44.1819 10.05 42.7152 10.05C41.4152 10.05 40.3486 10.3333 39.5152 10.9C38.6819 11.4667 38.1819 12.2333 38.0152 13.2H31.2152C31.4486 10.5667 32.6152 8.53333 34.7152 7.1C36.8152 5.63333 39.5986 4.9 43.0652 4.9C46.6986 4.9 49.4986 5.7 51.4652 7.3C53.4652 8.9 54.4652 11.2167 54.4652 14.25V23.3C54.4652 23.9333 54.5986 24.3667 54.8652 24.6C55.1319 24.8333 55.5486 24.95 56.1152 24.95H56.9152ZM47.5152 19.8H42.3652C40.8986 19.8 39.7486 20.1 38.9152 20.7C38.1152 21.2667 37.7152 22.0833 37.7152 23.15C37.7152 24.05 38.0486 24.7667 38.7152 25.3C39.4152 25.8333 40.3486 26.1 41.5152 26.1C43.3486 26.1 44.7986 25.5833 45.8652 24.55C46.9319 23.4833 47.4819 22.0667 47.5152 20.3V19.8Z"/><path d="M61.2926 11.15H57.0426V5.2H61.2926V0H68.3426V5.2H74.1926V11.15H68.3426V22.4C68.3426 23.3 68.5259 23.95 68.8926 24.35C69.2926 24.75 69.9426 24.95 70.8426 24.95H74.4926V30.9H68.6426C63.7426 30.9 61.2926 28.45 61.2926 23.55V11.15Z"/><path d="M76.0742 18.1C76.0742 15.4333 76.6076 13.1167 77.6742 11.15C78.7742 9.15 80.2909 7.61667 82.2242 6.55C84.1909 5.45 86.4576 4.9 89.0242 4.9C91.6242 4.9 93.9076 5.41667 95.8742 6.45C97.8742 7.45 99.4242 8.88334 100.524 10.75C101.658 12.5833 102.241 14.75 102.274 17.25C102.274 18.15 102.208 18.95 102.074 19.65H83.4242V19.85C83.5909 21.7167 84.1909 23.1833 85.2242 24.25C86.2576 25.3167 87.6742 25.85 89.4742 25.85C90.9076 25.85 92.0909 25.55 93.0242 24.95C93.9909 24.3167 94.6242 23.4 94.9242 22.2H101.874C101.608 23.9 100.958 25.4333 99.9242 26.8C98.8909 28.1667 97.5242 29.25 95.8242 30.05C94.1242 30.8167 92.1742 31.2 89.9742 31.2C87.1076 31.2 84.6242 30.6667 82.5242 29.6C80.4576 28.5333 78.8576 27.0167 77.7242 25.05C76.6242 23.05 76.0742 20.7333 76.0742 18.1ZM95.2242 15.05C94.9909 13.4833 94.3409 12.2833 93.2742 11.45C92.2409 10.5833 90.9242 10.15 89.3242 10.15C87.7909 10.15 86.4909 10.6 85.4242 11.5C84.3909 12.3667 83.7742 13.55 83.5742 15.05H95.2242Z"/></g>
      </svg><p>Dateworld sammenligner priser, vilkår og funktioner hos de datingtjenester, vi samarbejder med.</p></div>
      <div><h3>Datingsider</h3><ul><li><a href="/datingsider/">Bedste datingsider</a></li><li><a href="/bedste-dating-apps/">Bedste dating apps</a></li><li><a href="/gratis-dating/">Gratis dating</a></li><li><a href="/serioes-dating/">Seriøs dating</a></li><li><a href="/sexdating/">Fræk dating</a></li></ul></div><div><h3>Målgrupper</h3><ul><li><a href="/dating-for-unge/">Dating for unge</a></li><li><a href="/dating-40-plus/">Dating 40+</a></li><li><a href="/dating-50-plus/">Dating 50+</a></li><li><a href="/dating-for-seniorer/">Dating for seniorer</a></li><li><a href="/boesse-dating/">LGBT+ dating</a></li><li><a href="/kristen-dating/">Kristen dating</a></li></ul></div><div><h3>Anmeldelser</h3><ul><li><a href="/dating-dk-anmeldelse/">Dating.dk</a></li><li><a href="/single-dk-anmeldelse/">Single.dk</a></li><li><a href="/senior-dk-anmeldelse/">Senior.dk</a></li><li><a href="/singles50-anmeldelse/">Singles50</a></li><li><a href="/be2-anmeldelse/">be2</a></li><li><a href="/anmeldelser/">Alle anmeldelser</a></li></ul></div><div><h3>Guides</h3><ul><li><a href="/date-ideer/">Date ideer</a></li><li><a href="/tinder-bio/">Tinder bio</a></li><li><a href="/artikler/">Den første besked</a></li><li><a href="/artikler/">Sikker netdating</a></li><li><a href="/artikler/">Alle guides</a></li></ul></div>
    </div>
    <div class="foot-bot">
      <span class="ad"><span class="pill">Reklame</span>Siden indeholder affiliatelinks</span>
      <nav aria-label="Om siden"><a href="/om-os/">Om Dateworld</a><a href="/saadan-arbejder-vi/">Sådan tjener vi penge</a><a href="/om-os/#kontakt">Kontakt</a><a href="/privatlivspolitik/">Cookies og privatliv</a></nav>
      <span>© 2026 Dateworld · Drives af Mondae · CVR 37208329</span>
    </div>
  </div>
</footer>
<script>var U={"Bedste datingsider": "/datingsider/", "Se alle datingsider": "/datingsider/", "Datingsider": "/datingsider/", "Bedste dating apps": "/bedste-dating-apps/", "Gratis dating": "/gratis-dating/", "Gratis dating apps": "/gratis-dating-apps/", "Seriøs dating": "/serioes-dating/", "Elitedating": "/elitedating/", "Netdating": "/netdating/", "Tinder-alternativer": "/tinder-alternativer/", "Tinder alternativer": "/tinder-alternativer/", "Dating for unge": "/dating-for-unge/", "Dating 40+": "/dating-40-plus/", "Dating 50+": "/dating-50-plus/", "Dating 60+": "/dating-60-plus/", "Dating for seniorer": "/dating-for-seniorer/", "Senior dating": "/senior-dating/", "Bøsse dating": "/boesse-dating/", "Lesbisk dating": "/lesbisk-dating/", "Biseksuel dating": "/biseksuel-dating/", "Kristen dating": "/kristen-dating/", "Landmand dating": "/landmand-dating/", "Enlige forældre": "/dating-for-enlige-foraeldre/", "Dating for handicappede": "/dating-for-handicappede/", "Dating.dk eller Single.dk?": "/dating-dk-eller-single-dk/", "Se sammenligningen": "/dating-dk-eller-single-dk/", "Sexdating": "/sexdating/", "Fræk dating": "/sexdating/", "Se alt om fræk dating": "/sexdating/", "Start med sammenligningen": "/sexdating/", "Find en bolleven": "/find-bolleven/", "Utro dating": "/utro-dating/", "Sugardating": "/sugardating/", "Swingerdating": "/swingerdating/", "Se alle anmeldelser": "/anmeldelser/", "Anmeldelser": "/anmeldelser/", "Alle anmeldelser": "/anmeldelser/", "Date ideer": "/date-ideer/", "Find date ideer": "/date-ideer/", "Tinder bio": "/tinder-bio/", "Hvordan får man en kæreste?": "/hvordan-faar-man-en-kaereste/", "Første date": "/foerste-date/", "Den første date": "/foerste-date/", "Spørgsmål til daten": "/spoergsmaal-til-date/", "Date ideer hjemme": "/date-ideer-hjemme/", "Dating profiltekst": "/dating-profiltekst/", "profiltekst": "/dating-profiltekst/", "Kan han lide mig?": "/kan-han-lide-mig/", "10 tegn på, at han er vild med dig": "/10-tegn-paa-at-han-er-vild-med-dig/", "Kærestesorg": "/kaerestesorg/", "Se alle guides": "/artikler/", "Alle guides": "/artikler/", "Guides": "/artikler/", "Om Dateworld": "/om-os/", "Om os": "/om-os/", "Sådan arbejder vi": "/saadan-arbejder-vi/", "Sådan tjener vi penge": "/saadan-arbejder-vi/", "Sådan vurderer vi": "/saadan-arbejder-vi/", "Kontakt": "/om-os/#kontakt", "Cookies og privatliv": "/privatlivspolitik/", "Privatlivspolitik": "/privatlivspolitik/", "Forside": "/", "Dating apps": "/datingapps/", "Datingformer": "/datingformer/", "Den første besked": "/artikler/", "Falske profiler": "/artikler/", "Dating.dk": "/dating-dk-anmeldelse/", "Single.dk": "/single-dk-anmeldelse/", "Senior.dk": "/senior-dk-anmeldelse/", "Scor.dk": "/scor-dk-anmeldelse/", "Sexhunt.dk": "/sexhunt-anmeldelse/", "Erox.dk": "/erox-anmeldelse/", "Victoria Milan": "/victoria-milan-anmeldelse/", "C-Date": "/c-date-anmeldelse/", "Singles50": "/singles50-anmeldelse/", "Academic Singles": "/academic-singles-anmeldelse/", "be2": "/be2-anmeldelse/", "NextLove": "/nextlove-anmeldelse/", "Tinder": "/tinder-anmeldelse/", "Hinge": "/hinge-anmeldelse/", "Bumble": "/bumble-anmeldelse/", "Badoo": "/badoo-anmeldelse/", "Happn": "/happn-anmeldelse/", "Grindr": "/grindr-anmeldelse/", "40plus.dk": "/40plus-dk-anmeldelse/", "Scor": "/scor-dk-anmeldelse/", "Nextlove": "/nextlove-anmeldelse/", "iDates": "/idates-anmeldelse/", "Only-flirts": "/only-flirts-anmeldelse/", "Meet-n-Hook": "/meet-n-hook-anmeldelse/", "Swirvy Date": "/swirvy-date-anmeldelse/", "LGBT+ dating": "/boesse-dating/", "Siden indeholder affiliatelinks": "/saadan-arbejder-vi/", "Læs, hvordan vi arbejder": "/saadan-arbejder-vi/", "Sikker netdating": "/artikler/", "Læs anmeldelserne": "/anmeldelser/", "sammenligning af datingsider": "/datingsider/", "guides til dating": "/artikler/", "dating app": "/bedste-dating-apps/", "anmeldelser af datingsider": "/anmeldelser/", "Sammenlign datingsider": "/datingsider/", "Se forslag": null, "swingere": "/swingerdating/", "swingerklub": "/swingerdating/", "falske profiler": "/artikler/", "Du søger en kæreste": "/datingsider/", "Flirt og fræk dating": "/sexdating/", "Bøsse og lesbisk dating": "/boesse-dating/", "Gratis at starte": "/gratis-dating/"};function uu(t){return U[t]||"#";}
(function(){
  function ic(d){return '<svg aria-hidden="true" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+d+'</svg>';}
  var I={
    trophy:ic('<path d="M8 4h8v5a4 4 0 0 1-8 0Z"/><path d="M8 6H5v1.5A3 3 0 0 0 8 10.5M16 6h3v1.5a3 3 0 0 1-3 3M12 13v4M8.5 20h7M10 17h4"/>'),
    heart:ic('<path d="M12 20s-7-4.3-7-9.6A3.9 3.9 0 0 1 12 8a3.9 3.9 0 0 1 7 2.4C19 15.7 12 20 12 20Z"/>'),
    lock:ic('<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>'),
    cup:ic('<path d="M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5Z"/><path d="M16 10.5h1.5a2.5 2.5 0 0 1 0 5H16M8 3.5c-.6.9-.6 1.6 0 2.5M11.5 3.5c-.6.9-.6 1.6 0 2.5"/>'),
    pen:ic('<path d="M4 20l1-4L16 5l3 3L8 19Z"/><path d="M14 7l3 3"/>'),
    ring:ic('<circle cx="12" cy="15.2" r="5.6"/><path d="M9.4 6.4 12 9.6l2.6-3.2-1.3-2h-2.6l-1.3 2Z"/>'),
    flame:ic('<path d="M12 21c3.6 0 6-2.5 6-5.9 0-3.3-2.3-4.9-3.1-8.1-2 .9-3 2.7-3.1 4.3C10.6 10.4 9.9 9 10 7 7.9 8.9 6 11.6 6 15.1 6 18.5 8.4 21 12 21Z"/><path d="M12 21c1.5 0 2.5-1 2.5-2.4 0-1.3-.9-2-1.4-3.2-1.1.7-1.6 1.6-1.7 2.6-.5-.2-.8-.5-1-.9-.5.5-.9 1.1-.9 1.8 0 1.2 1 2.1 2.5 2.1Z"/>'),
    rainbow:ic('<path d="M4 17a8 8 0 0 1 16 0M7 17a5 5 0 0 1 10 0M10 17a2 2 0 0 1 4 0"/>'),
    '50+':ic('<circle cx="12" cy="12" r="9.3"/><text x="12" y="14.8" text-anchor="middle" font-size="7.4" font-weight="600" fill="currentColor" stroke="none">50+</text>'),
    '0 kr.':ic('<circle cx="12" cy="12" r="9.3"/><text x="12" y="14.9" text-anchor="middle" font-size="8" font-weight="600" fill="currentColor" stroke="none">0,-</text>'),
    '40+':ic('<circle cx="12" cy="12" r="9.3"/><text x="12" y="14.8" text-anchor="middle" font-size="7.4" font-weight="600" fill="currentColor" stroke="none">40+</text>'),
    star:ic('<path d="m12 4 2.4 5 5.4.7-4 3.8 1 5.4L12 16.3 7.2 18.9l1-5.4-4-3.8 5.4-.7L12 4Z"/>'),
    cross:ic('<path d="M12 3.5v17M7 8.5h10"/>'),
    family:ic('<circle cx="9" cy="7" r="2.8"/><path d="M3.5 19c.4-3.4 2.6-5.2 5.5-5.2 1.6 0 3 .6 4 1.6"/><circle cx="16.5" cy="13" r="2"/><path d="M13 20c.3-2 1.6-3.2 3.5-3.2S19.7 18 20 20"/>'),
    heart:ic('<path d="M12 19.5s-7-4.3-7-9.7A3.9 3.9 0 0 1 12 7.600a3.9 3.9 0 0 1 7 2.200c0 5.4-7 9.7-7 9.700Z"/>'),
    phone:ic('<rect x="7" y="3" width="10" height="18" rx="2.5"/><path d="M11 17.6h2"/>')
  };
  var bigArrow='<svg aria-hidden="true" width="24" height="24" viewBox="0 0 22 22" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11h14M12.5 5.5 18 11l-5.5 5.5"/></svg>';
  var arrow='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 22 22" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11h14M12.5 5.5 18 11l-5.5 5.5"/></svg>';
  var chev='<svg aria-hidden="true" width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4.5 6 8l3.5-3.5"/></svg>';
  var panels=[
    {id:'sites',label:'Datingsider',
     spot:[['Bedste datingsider','Sammenlign de mest populære datingtjenester','trophy'],['Bedste dating apps','Apps til både seriøs og uforpligtende dating','phone'],['Gratis dating','Se, hvad du får uden at betale','0 kr.']],
     cols:[['Type',['Seriøs dating','Elitedating','Netdating','Tinder-alternativer']],
           ['Efter alder',['Dating for unge','Dating 40+','Dating 50+','Dating 60+','Dating for seniorer']],
           ['Målgrupper',['Bøsse dating','Lesbisk dating','Biseksuel dating','Kristen dating','Landmand dating','Enlige forældre']]],
     foot:['Dating.dk eller Single.dk?','Se sammenligningen','Se alle datingsider']},
    {id:'fraek',label:'Fræk dating',
     spot:[['Sexdating','Sammenlign de frække datingtjenester','flame'],['Find en bolleven','Uforpligtende aftaler med én, du kender','heart'],['Utro dating','Diskrete tjenester til en affære','lock']],
     cols:[['Mere',['Sugardating','Swingerdating']],
           ['Anmeldelser',['Scor.dk','Sexhunt.dk','Erox.dk','Victoria Milan','C-Date']]],
     foot:['Ny til sexdating?','Start med sammenligningen','Se alt om fræk dating']},
    {id:'reviews',label:'Anmeldelser',
     cols:[['Datingsider',['Dating.dk','Single.dk','Academic Singles','Nextlove','be2']],
           ['40+ og senior',['Senior.dk','Singles50','40plus.dk']],
           ['Dating apps',['Tinder','Hinge','Bumble','Badoo','Happn']],
           ['Fræk dating',['Scor.dk','Sexhunt.dk','Erox.dk','Victoria Milan','C-Date']]],
     foot:['Priser, Trustpilot-vurdering og hvad du får gratis.','','Se alle anmeldelser']},
    {id:'guides',label:'Guides',
     spot:[['Date ideer','Fra den første kaffe til årsdagen','cup'],['Tinder bio','Skriv en profil, der får svar','pen'],['Hvordan får man en kæreste?','Råd til at finde den rigtige','ring']],
     cols:[['Dates',['Første date','Spørgsmål til daten','Date ideer hjemme']],
           ['Din profil',['Dating profiltekst']],
           ['Kærlighed',['Kan han lide mig?','10 tegn på, at han er vild med dig','Kærestesorg']]],
     foot:['Skal I ud i weekenden?','Find date ideer','Se alle guides']}
  ];
  var hd=document.getElementById('hd'),nav=document.getElementById('nav'),mega=document.getElementById('mega'),panel=document.getElementById('panel'),burger=document.getElementById('burger');
  var open=null,openT=null,closeT=null;
  var desk=window.matchMedia('(min-width:1021px)'),hov=window.matchMedia('(hover:hover) and (min-width:1021px)');
  function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function byId(id){return panels.filter(function(p){return p.id===id;})[0];}
  function render(p){
    var n=p.cols.length,h='';
    h+='<div class="panel-body'+(p.spot?'':' nospot')+'" style="grid-template-columns:'+(p.spot?'360px ':'')+'repeat('+n+',minmax(0,1fr))">';
    if(p.spot){h+='<div class="spot">'+p.spot.map(function(s){return '<a href="'+uu(s[0])+'"><span class="sico">'+(I[s[2]]||esc(s[2]))+'</span><span class="st"><b>'+esc(s[0])+'</b><small>'+esc(s[1])+'</small></span>'+arrow+'</a>';}).join('')+'</div>';}
    h+=p.cols.map(function(c){return '<div class="col"><h3>'+esc(c[0])+'</h3>'+c[1].map(function(t){return '<a href="'+uu(t)+'">'+esc(t)+'</a>';}).join('')+'</div>';}).join('');
    h+='</div><div class="panel-foot"><span>'+esc(p.foot[0])+(p.foot[1]?' <a href="'+uu(p.foot[1])+'">'+esc(p.foot[1])+arrow+'</a>':'')+'</span><a href="'+uu(p.foot[2])+'">'+esc(p.foot[2])+arrow+'</a></div>';
    panel.innerHTML=h;
  }
  function show(id){
    var p=byId(id);open=id;render(p);
    panels.forEach(function(x){x.btn.setAttribute('aria-expanded',String(x.id===id));});
    if(desk.matches){hd.appendChild(mega);}else{p.btn.after(mega);}
    mega.classList.add('show');
  }
  function hide(){
    open=null;mega.classList.remove('show');
    panels.forEach(function(x){x.btn.setAttribute('aria-expanded','false');});
  }
  panels.forEach(function(p){
    var b=document.createElement('button');
    b.type='button';b.className='navbtn';b.setAttribute('aria-expanded','false');b.setAttribute('aria-controls','mega');
    b.innerHTML='<span>'+esc(p.label)+'</span>'+chev;
    b.addEventListener('click',function(){if(hov.matches||open!==p.id){show(p.id);}else{hide();}});
    b.addEventListener('mouseenter',function(){if(!hov.matches)return;clearTimeout(closeT);clearTimeout(openT);openT=setTimeout(function(){show(p.id);},open?0:70);});
    b.addEventListener('mouseleave',function(){clearTimeout(openT);});
    p.btn=b;nav.appendChild(b);
  });
  hd.addEventListener('mouseleave',function(){if(!hov.matches)return;clearTimeout(openT);closeT=setTimeout(hide,220);});
  hd.addEventListener('mouseenter',function(){clearTimeout(closeT);});
  burger.addEventListener('click',function(){
    var on=nav.classList.toggle('open');
    burger.setAttribute('aria-expanded',String(on));
    burger.setAttribute('aria-label',on?'Luk menu':'Åbn menu');
    if(!on){hide();}
  });
  document.addEventListener('click',function(e){if(open&&!e.target.closest('header')){hide();}});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&open){var b=byId(open).btn;hide();b.focus();}});

  if(document.getElementById('chips'))document.getElementById('chips').innerHTML=[['ring','Et seriøst forhold','Seriøs dating'],['flame','Noget uforpligtende','Flirt og fræk dating'],['50+','Dating for 50+','Til dig over 50'],['0 kr.','Gratis at starte','Gratis dating'],['rainbow','LGBT+ dating','Bøsse og lesbisk dating'],['phone','En dating app','Bedste dating apps']].map(function(c){
    return '<a href="'+(U[c[2]]||U[c[1]]||'#')+'"><span class="ico">'+(I[c[0]]||esc(c[0]))+'</span><span class="t"><b>'+esc(c[1])+'</b><small>'+esc(c[2])+'</small></span><span class="go-i">'+bigArrow+'</span></a>';
  }).join('');
  (function(){
    var rail=document.getElementById('rail'),prev=document.getElementById('catPrev'),next=document.getElementById('catNext');
    if(!rail){return;}
    rail.innerHTML=[['50+','Dating for seniorer','Datingsider til dig over 50'],['40+','Dating 40+','Til dig, der er midt i livet'],['rainbow','LGBT+ dating','Bøsse, lesbisk og biseksuel dating'],['flame','Fræk dating','Sexdating og uforpligtende møder'],['star','Elitedating','Til singler med uddannelse og karriere'],['cross','Kristen dating','Mød singler, der deler din tro'],['family','Enlige forældre','Dating, når du har børn'],['phone','Dating for unge','Apps og sider til dig i 20\'erne']].map(function(c){
      return '<a class="cat" href="'+(U[c[1]]||'#')+'"><span class="ico">'+I[c[0]]+'</span><span class="row"><span><h3>'+esc(c[1])+'</h3><p>'+esc(c[2])+'</p></span><span class="go-i">'+bigArrow+'</span></span></a>';
    }).join('');
    function upd(){prev.disabled=rail.scrollLeft<4;next.disabled=rail.scrollLeft+rail.clientWidth>=rail.scrollWidth-4;}
    function step(d){rail.scrollBy({left:d*(rail.clientWidth+16),behavior:'smooth'});}
    prev.addEventListener('click',function(){step(-1);});next.addEventListener('click',function(){step(1);});
    rail.addEventListener('scroll',upd,{passive:true});window.addEventListener('resize',upd);upd();
  })();
  (function(){
    var last=window.scrollY,out=null,wait=null,up=0,down=0;
    window.addEventListener('scroll',function(){
      var y=window.scrollY,d=y-last;last=y;
      if(y<=32){clearTimeout(out);clearTimeout(wait);wait=null;up=0;down=0;hd.classList.remove('fix','in');return;}
      if(d<0){
        up-=d;down=0;
        if(up>90&&y>220&&!hd.classList.contains('in')&&!wait){
          wait=setTimeout(function(){
            wait=null;clearTimeout(out);
            if(!hd.classList.contains('fix')){hd.classList.add('fix');void hd.offsetWidth;}
            hd.classList.add('in');
          },220);
        }
      }else if(d>0){
        down+=d;
        if(down>48){
          up=0;clearTimeout(wait);wait=null;
          if(hd.classList.contains('in')){
            if(open){hide();}
            nav.classList.remove('open');burger.setAttribute('aria-expanded','false');
            hd.classList.remove('in');
            clearTimeout(out);out=setTimeout(function(){hd.classList.remove('fix');},720);
          }
        }
      }
    },{passive:true});
    if(location.hash==='#pin'){window.scrollTo(0,640);setTimeout(function(){clearTimeout(out);hd.classList.add('fix','in');},700);}
  })();
  if(location.hash==='#menu'){show('sites');}
})();
</script>
<?php wp_footer(); ?>
</body>
</html>
